title: 'Pygame Zero'
subtitle:
speaker: daniel-pope
---
Pygame Zero is a zero-boilerplate games framework for education.

Daniel will describe the framework and walk through getting started with it, as well as explaining some of the background behind Pygame Zero and the motivation to tackle educational projects. 