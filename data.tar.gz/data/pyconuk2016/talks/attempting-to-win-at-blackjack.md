title: 'Attempting to Win at Blackjack'
subtitle:
speaker: william-dudley
---
How risky should you be when playing blackjack? Without card-counting, is there any way you can 'beat the dealer'? Do riskier players win more than safer players? This talk addresses these questions using some Python code I wrote after just a few months of learning the language.