title: 'Getting started with requests HTTP library'
subtitle:
speaker: andrea-grandi
---
requests is one of the most advanced and simple to use HTTP libraries. The presentations is going to show how to get started with it, how to consume REST APIs and last but not least how to properly mock and test our code.