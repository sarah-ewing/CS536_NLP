title: "Tech interviews that don't suck"
subtitle:
speaker: marc-tamlyn
---
For many interviewees and interviewers, hiring engineers is a difficult and stressful process. It's widely regarded that inverting a binary tree on a whiteboard is not a great approach to finding the best people to work with, but what is?

I recently had the opportunity to design an interview process from scratch. We will look at the interview process I created, its strengths, weaknesses and inspiration.