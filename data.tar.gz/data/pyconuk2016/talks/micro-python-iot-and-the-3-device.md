title: 'Micro Python, the Internet of Things and the £3 device'
subtitle:
speaker: kirk-northrop
---
The Internet of Things has been talked about hugely over the last ten years, but with the rise of the Raspberry Pi and Arduino, it is suddenly starting to become real. Nowadays, you can build an entire, WiFi connected device for £3 including the batteries and using Micro Python.